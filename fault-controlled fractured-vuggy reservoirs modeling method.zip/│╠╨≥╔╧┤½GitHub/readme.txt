Research on reservoir modeling method for fault-controlled fractured-vuggy reservoirs-taking Shunbei Fault Zone No. 5 as an example
Haojie Shang, Shuyang Chen, Yunfeng He, Lixin Wang, Yanshu Yin, Pengfei Xie

Code availability section
Name of the code/library ：for fracture plane simulation: DM; for cave type simulation: DX
Contact: e-mail and phone number : 2023730052@yangtzeu.edu.cn; 18339165595
Hardware requirements: CPU: Core i9 3.70GHz
Program language: Python
Software required: Vscode
Program size: for fracture plane(DM): 16Kb; for cave type(DX): 54Kb.
